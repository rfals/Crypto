# triplesma

Is a repo where I form a hypothesis, develop an algorithmic trading strategy, backtest the strategy, optimize the strategy and implement the strategy.

